#include "stdafx.h"
#include "Obstacle.h"

Obstacle::Obstacle() {

}

Obstacle::~Obstacle() {

}

void Obstacle::Animate(double _timeElapsed) {
	

	GameObject::Animate(_timeElapsed);
}