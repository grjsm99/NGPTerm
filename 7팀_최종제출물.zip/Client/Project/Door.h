#pragma once
#include "GameObject.h"
#include "Obstacle.h"

class Door : public Obstacle {
public:
	Door();
	virtual ~Door();
};

