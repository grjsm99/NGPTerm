#include "stdafx.h"
#include "Scene.h"
#include "Timer.h"
#include "GameFramework.h"

#include "../../protocol.h"


Scene::Scene() {
	
}

Scene::~Scene() {
	
}

void Scene::CheckCollision() {

}

///////////////////////////////////////////////////////////////////////////////
/// PlayScene
PlayScene::PlayScene(int _stageNum) {
	globalAmbient = XMFLOAT4(0.1f, 0.1f, 0.1f, 1.0f);
	keybufferTime = 0;
	playerHP = 100;
	missileCount = 0;
	// ���������� �ʱⰪ���� �ٲپ�����
	prevPosition = XMFLOAT3(0, 0, 0);
	prevRotation = XMFLOAT4(0, 0, 0, 1);
}

void PlayScene::Init(const ComPtr<ID3D12Device>& _pDevice, const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {
	GameFramework& gameFramework = GameFramework::Instance();
	// �������� ����
	LoadStage(_pDevice, _pCommandList);
	camera = make_shared<Camera>();
	camera->Create(_pDevice, _pCommandList);

	camera->SetLocalPosition(XMFLOAT3(0.0, 10.0, -20)); // pPlayer ������

	camera->SetLocalRotation(Vector4::QuaternionRotation(XMFLOAT3(0,1,0), 0.0f));
	camera->UpdateLocalTransform();
	camera->UpdateWorldTransform();
	pPlayer->SetChild(camera);

	pPlayer->UpdateObject();

	ComPtr<ID3D12Resource> temp;
	UINT ncbElementBytes = ((sizeof(LightsMappedFormat) + 255) & ~255); //256�� ���
	pLightsBuffer = ::CreateBufferResource(_pDevice, _pCommandList, NULL, ncbElementBytes, D3D12_HEAP_TYPE_UPLOAD, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER, temp);
	

	pLightsBuffer->Map(0, NULL, (void**)&pMappedLights);

	GameObject::Init(_pDevice, _pCommandList);
}

void PlayScene::ReleaseUploadBuffers() {
	GameFramework& gameFramework = GameFramework::Instance();
	gameFramework.GetMeshManager().ReleaseUploadBuffers();
	gameFramework.GetTextureManager().ReleaseUploadBuffers();
	for (auto& pUI : pUIs) {
		pUI.second->ReleaseUploadBuffers();
	}
}

PlayScene::~PlayScene() {
	pLightsBuffer->Unmap(0, NULL);
}

void PlayScene::ProcessKeyboardInput(const array<UCHAR, 256>& _keysBuffers, float _timeElapsed, const ComPtr<ID3D12Device>& _pDevice, const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {
	

	GameFramework& gameFramework = GameFramework::Instance();
	
	if (_keysBuffers['E'] & 0xF0) {
		pPlayer->RotateRigid(XMFLOAT3(0, 1, 0), 90.0f, _timeElapsed);
	}
	if (_keysBuffers['Q'] & 0xF0) {
		pPlayer->RotateRigid(XMFLOAT3(0, 1, 0), -90.0f, _timeElapsed);
	}
	if (_keysBuffers['3'] & 0xF0) {
		pPlayer->RotateRigid(pPlayer->GetLocalRightVector(), 90.0f, _timeElapsed);
	}
	if (_keysBuffers['4'] & 0xF0) {
		pPlayer->RotateRigid(pPlayer->GetLocalRightVector(), -90.0f, _timeElapsed);
	}
	
	if (_keysBuffers['W'] & 0xF0) {
		pPlayer->MoveFrontRigid(true, _timeElapsed);
	}
	if (_keysBuffers['S'] & 0xF0) {
		pPlayer->MoveFrontRigid(false, _timeElapsed);
	}
	if (_keysBuffers['D'] & 0xF0) {
		pPlayer->MoveRightRigid(true, _timeElapsed);
	}
	if (_keysBuffers['A'] & 0xF0) {
		pPlayer->MoveRightRigid(false, _timeElapsed);
	}
	if (_keysBuffers['1'] & 0xF0) {
		pPlayer->MoveUpRigid(true, _timeElapsed);
	}
	if (_keysBuffers['2'] & 0xF0) {
		pPlayer->MoveUpRigid(false, _timeElapsed);
	}
	if (_keysBuffers['P'] & 0xF0) {
		//pPlayer->FireMissile(missileCount, pMissiles, _pDevice, _pCommandList);
		if (pPlayer->GetReloadTime() < 0) {
			SendNewMissile();
			pPlayer->SetReloadTime(0.1f);
		}
	}
	//pPlayers[0]->ApplyTransform(transform, false);
}

void PlayScene::AnimateObjects(double _timeElapsed, const ComPtr<ID3D12Device>& _pDevice, const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {

	if (pPlayer->GetIsDead()) return;
	keybufferTime -= _timeElapsed;

	// �÷��̾ ����ִ� ��� �ִϸ��̼��� ����
	if (!pPlayer->GetIsDead()) {
		pPlayer->Animate(_timeElapsed);
		if (!same(prePlayerPosition, pPlayer->GetWorldPosition()) || !same(prePlayerRotation,pPlayer->GetLocalRotate())) {
			pPlayer->SendPlayerMove();
			prePlayerPosition = pPlayer->GetWorldPosition();
			prePlayerRotation = pPlayer->GetLocalRotate();
			
		}
		// ��Ŷ send
	}		

	for (auto& pLight : pLights) {
		if (pLight) {
			pLight->UpdateLight();
		}
	}
	for (auto& pEffect : pEffects) {
		if (pEffect) {
			pEffect->Animate(_timeElapsed);
		}
	}
	
	EnterCriticalSection(&missileCS);
	for (auto& pMissile : pMissiles) {
		pMissile->Animate(_timeElapsed);
	}
	LeaveCriticalSection(&missileCS);

	
	for (auto& pEnemy : pEnemys) {
		pEnemy->Animate(_timeElapsed);
	}
	pWater->Animate(_timeElapsed);
}

void PlayScene::CheckCollision() {

	EnterCriticalSection(&missileCS);
	
	
	// �̻��ϰ� �÷��̾��� �浹üũ (CheckCollideWithMissile)
	if (!pPlayer->GetIsInvisible()) {
		for (auto& pMissile : pMissiles) {
			if (pMissile->GetClientID() != pPlayer->GetClientID() && pMissile->GetObj()->GetBoundingBox().Contains(pPlayer->GetObj()->GetBoundingBox())) {
				pMissile->Remove(); 
				playerHP = pPlayer->Hit(5.0f);
				if (playerHP <= 0) {
					GameFramework::Instance().SetGameOver();	// �÷��̾��� ü���� 0���ϰ� �ɰ�� ���ӷ����� �������´�.
				}
				// ������ �̻����� id�� ������ �����ش�.
				if (!SendMissileRemove(pMissile->GetMissileID()))
					cout << "SendMissileRemove_Error" << endl;

				pUIs["2DUI_hp"]->SetSizeUV(XMFLOAT2(playerHP / 100.0f, 1.0f));

				shared_ptr<Effect> pEffect = make_shared<Effect>();
				pEffect->Create(0.03, 8, 8, 50, 50, pMissile->GetLocalPosition(), "Explode_8x8");

				pEffects.push_back(pEffect);
				break;
			}
		}
	}
	pMissiles.remove_if([](const shared_ptr<GameObject>& _pMissile) {
		return _pMissile->CheckRemove();
		});

	LeaveCriticalSection(&missileCS);


	EnterCriticalSection(&playerCS);
	pEnemys.remove_if([](const shared_ptr<Player>& pEnemy) {
		return pEnemy->GetIsDead();
		});
	LeaveCriticalSection(&playerCS);


	pEffects.remove_if([](const shared_ptr<Effect>& pEffect) {
		return pEffect->CheckRemove();
		});
}

void PlayScene::UpdateShaderVariables(const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {
	// ���� ���� ����� ���ҽ� ���� ���� ����.
	int i = 0;
	for (auto& pEnemy : pEnemys) {
		pEnemy->UpdateShaderVariableInstance(_pCommandList, i++);
	}
}

void PlayScene::UpdateLightShaderVariables(const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {
	int nLight = (UINT)pLights.size();
	for (int i = 0; i < nLight; ++i) {
		
		memcpy(&pMappedLights->lights[i], pLights[i].get(), sizeof(Light));
	}

	memcpy(&pMappedLights->globalAmbient, &globalAmbient, sizeof(XMFLOAT4));

	memcpy(&pMappedLights->nLight, &nLight, sizeof(int));

	D3D12_GPU_VIRTUAL_ADDRESS gpuVirtualAddress = pLightsBuffer->GetGPUVirtualAddress();
	_pCommandList->SetGraphicsRootConstantBufferView(2, gpuVirtualAddress);

}

void PlayScene::Render(const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {	

	GameFramework& gameFramework = GameFramework::Instance();
	camera->SetViewPortAndScissorRect(_pCommandList);
	camera->UpdateShaderVariable(_pCommandList);

	UpdateLightShaderVariables(_pCommandList);
	if (pPlayer->GetIsDead()) {
		Image2D::GetShader()->PrepareRender(_pCommandList);
		pUIs["2DUI_gameover"]->Render(_pCommandList);
		return;
	}
	//UpdateShaderVariables(_pCommandList);

	Image2D::GetShader()->PrepareRender(_pCommandList);
	pUIs["2DUI_hpbar"]->Render(_pCommandList);
	pUIs["2DUI_hp"]->Render(_pCommandList);
	
	TerrainMesh::GetShader()->PrepareRender(_pCommandList);
	pTerrain->Render(_pCommandList);
	
	BillBoardMesh::GetShader()->PrepareRender(_pCommandList);
	for (auto& billboard : pBillBoards) {
		billboard->Render(_pCommandList);
	}
	for (auto& pEffect : pEffects) {
		pEffect->Render(_pCommandList);
	}
	
	Mesh::GetShader()->PrepareRender(_pCommandList);
	pPlayer->Render(_pCommandList);	
	
	float isinv = 0;
	_pCommandList->SetGraphicsRoot32BitConstants(6, 1, &isinv, 0);
	
	EnterCriticalSection(&missileCS);
	for (auto& pMissile : pMissiles) {
		if (pMissile) pMissile->Render(_pCommandList);
	}
	LeaveCriticalSection(&missileCS);

	
	EnterCriticalSection(&playerCS);
	for (auto& pEnemy : pEnemys) {
		if (pEnemy) pEnemy->Render(_pCommandList);
	}
	LeaveCriticalSection(&playerCS);

	WaterMesh::GetShader()->PrepareRender(_pCommandList);
	pWater->Render(_pCommandList);
	

	SkyBoxMesh::GetShader()->PrepareRender(_pCommandList);
	pSkyBox->Render(_pCommandList, camera);
}

void PlayScene::AddLight(const shared_ptr<Light>& _pLight) {
	pLights.push_back(_pLight);
}

void PlayScene::AddEnemy(const SC_ADD_PLAYER& _packet, bool _isNew, const ComPtr<ID3D12Device>& _pDevice, const ComPtr<ID3D12GraphicsCommandList>& _pCommandList)
{
	shared_ptr<Player> pEnemy = make_shared<Player>();
	pEnemy->Create("Gunship", _pDevice, _pCommandList);
	pEnemy->SetInvisible(_isNew);
	//pEnemy->SetLocalScale(XMFLOAT3(22,22,22));

	pEnemy->SetLocalPosition(_packet.localPosition);
	pEnemy->SetLocalRotation(_packet.localRotation);
	pEnemy->SetLocalScale(XMFLOAT3(3.0f, 3.0f, 3.0f));
	pEnemy->UpdateObject();
	pEnemy->SetClientID(_packet.client_id);

	EnterCriticalSection(&playerCS);
	pEnemys.push_back(pEnemy);
	LeaveCriticalSection(&playerCS);

}

void PlayScene::AddMissile(const SC_ADD_MISSILE& _packet, const ComPtr<ID3D12Device>& _pDevice, const ComPtr<ID3D12GraphicsCommandList>& _pCommandList)
{
	shared_ptr<Missile> pMissile = make_shared<Missile>();
	pMissile->Create(_packet.client_id, _packet.missile_id, _packet.position, _packet.rotation, _pDevice, _pCommandList);
	
	EnterCriticalSection(&missileCS);
	pMissiles.push_back(pMissile);
	LeaveCriticalSection(&missileCS);
}

void PlayScene::EnemyMove(const SC_MOVE_PLAYER& _packet)
{
	EnterCriticalSection(&playerCS);
	auto target = find_if(pEnemys.begin(), pEnemys.end(), [_packet](const shared_ptr<Player>& _p) { return _p->GetClientID() == _packet.client_id; });
	// ���� �� �÷��̾�� �Ӱ迵���� ���� ����� �������ֵ��� �ٲ� ����
	
	// ���� �÷��̾ �̹� ���� ���¸� ��Ŷ�� ó������ �ʴ´�.
	if (target != pEnemys.end()) {
		(*target)->SetLocalPosition(_packet.localPosition);
		(*target)->SetLocalRotation(_packet.localRotation);
		(*target)->UpdateObject();
	}	
	LeaveCriticalSection(&playerCS);
}

void PlayScene::RemoveMissile(const SC_REMOVE_MISSILE& _packet)
{
	EnterCriticalSection(&missileCS);
	auto target = lower_bound(pMissiles.begin(), pMissiles.end(), _packet.missile_id, [](const shared_ptr<Missile>& _p, UINT _mid) { return _p->GetMissileID() < _mid; });
	// �� �̻����� ���� �������� �� ( �̻����� �̹� �ð��� ���� ������� �� �ִ� )
	if (target != pMissiles.end()) {
		(*target)->Remove();
		pUIs["2DUI_hp"]->SetSizeUV(XMFLOAT2(playerHP / 100.0f, 1.0f));
		
		shared_ptr<Effect> pEffect = make_shared<Effect>();
		pEffect->Create(0.03, 8, 8, 50, 50, (*target)->GetLocalPosition(), "Explode_8x8");

		pEffects.push_back(pEffect);
	}
	LeaveCriticalSection(&missileCS);
}

void PlayScene::RemoveEnemy(const SC_REMOVE_PLAYER& _packet)
{
	EnterCriticalSection(&playerCS);
	auto target = find_if(pEnemys.begin(), pEnemys.end(), [_packet](const shared_ptr<Player>& _p) { return _p->GetClientID() == _packet.client_id; });
	(*target)->SetIsDead();
	LeaveCriticalSection(&playerCS);
}

int PlayScene::SendNewMissile() {
	//�� ������ �Լ����� cid�� �����Ƿ�  Ÿ�Ը� �����ָ� �ȴ�.
	int result;
	CS_ADD_MISSILE packet;
	packet.type = 1;
	result = send(serverSock, (char*)&packet, sizeof(packet), 0);
	if (result == SOCKET_ERROR) {
		err_display("SendNewMissile()");
		return -1;
	}
	return result;
}

shared_ptr<TerrainMap> PlayScene::GetTerrain() const {
	return pTerrain;
}

void PlayScene::LoadStage(const ComPtr<ID3D12Device>& _pDevice, const ComPtr<ID3D12GraphicsCommandList>& _pCommandList) {
	// ���� �׷��� ������Ʈ���� ���� ����.
	
	GameFramework& gameFramework = GameFramework::Instance();
	gameFramework.GetGameObjectManager().GetGameObject("Missile", _pDevice, _pCommandList);
	gameFramework.GetGameObjectManager().GetGameObject("Apache", _pDevice, _pCommandList);
	Effect::CreateBaseMesh(_pDevice, _pCommandList);
	Effect::LoadEffect("Explode_8x8", _pDevice, _pCommandList);
	
	pPlayer = make_shared<Player>();
	pPlayer->Create("Gunship", _pDevice, _pCommandList);
	pPlayer->SetLocalScale(XMFLOAT3(3.0f, 3.0f, 3.0f));
	pPlayer->UpdateObject();
	pPlayer->SetPlayer();
	prePlayerPosition = pPlayer->GetWorldPosition();
	prePlayerRotation = pPlayer->GetLocalRotate();

	shared_ptr<Light> baseLight = make_shared<Light>();
	baseLight->lightType = 3;
	baseLight->position = XMFLOAT3(0, 500, 0);
	baseLight->direction = XMFLOAT3(0, -1, 0);
	baseLight->diffuse = XMFLOAT4(0.1, 0.1, 0.1, 1);
	AddLight(baseLight);
	
	
	// size, startpos, uvsize
	// pos = x,y -> 0~2
	
	string name = "2DUI_hp";
	shared_ptr<Image2D> phpUI = make_shared<Image2D>(name, XMFLOAT2(0.6, 0.2), XMFLOAT2(1.385,1.75), XMFLOAT2(1,1), _pDevice, _pCommandList);
	pUIs[name] = phpUI;
	
	name = "2DUI_hpbar";
	phpUI = make_shared<Image2D>(name, XMFLOAT2(0.7, 0.3), XMFLOAT2(1.3, 1.7), XMFLOAT2(1, 1), _pDevice, _pCommandList);
	pUIs[name] = phpUI;
	
	name = "2DUI_gameover";
	phpUI = make_shared<Image2D>(name, XMFLOAT2(2, 2), XMFLOAT2(0,0), XMFLOAT2(1, 1), _pDevice, _pCommandList);
	pUIs[name] = phpUI;

	XMFLOAT3 size = XMFLOAT3(2056, 2056, 2056);
	pWater = make_shared<Water>(size, WATER_HEIGHT, _pDevice, _pCommandList);
	


	XMFLOAT3 tScale = XMFLOAT3(8.0f, 2.0f, 8.0f);
	XMFLOAT4 tColor = XMFLOAT4(0.0f, 0.5f, 0.0f, 0.0f);
	
	pTerrain = make_shared<TerrainMap>(_pDevice, _pCommandList, _T("Texture/HeightMap.raw"), 257, 257, 257, 257, tScale, tColor);
	RigidBody::pTerrain = pTerrain;

	shared_ptr<BillBoard> billboard; 
	
	billboard = make_shared<BillBoard>();
	billboard->Create("Flower01", _pDevice, _pCommandList);
	pBillBoards.push_back(billboard);

	billboard = make_shared<BillBoard>();
	billboard->Create("Flower02", _pDevice, _pCommandList);
	pBillBoards.push_back(billboard);
	
	billboard = make_shared<BillBoard>();
	billboard->Create("Grass01", _pDevice, _pCommandList);
	pBillBoards.push_back(billboard);
	
	billboard = make_shared<BillBoard>();
	billboard->Create("Tree02", _pDevice, _pCommandList);
	pBillBoards.push_back(billboard);

	billboard = make_shared<BillBoard>();
	billboard->Create("Tree03", _pDevice, _pCommandList);
	pBillBoards.push_back(billboard);

	pSkyBox = make_shared<SkyBox>();
	pSkyBox->Create(_pDevice, _pCommandList);
}

void PlayScene::SetPlayerClientID(USHORT _cid) {
	pPlayer->SetClientID(_cid);

}

// Ư�� Ŭ���̾�Ʈ�� � �̻��ϰ� �浹 �� �浹�� missile id�� ��ο��� Send �� ��� ���� �� true�� ��ȯ�Ѵ�
int PlayScene::SendMissileRemove(UINT _mid)
{	
	CS_REMOVE_MISSILE packet;
	packet.missile_id = _mid;
	int retval = send(serverSock, (char*)&packet, sizeof(packet), 0);

	if (retval == SOCKET_ERROR) {
		err_display("Error SendMissileRemove()");
		return -1;
	}

	return retval;
}