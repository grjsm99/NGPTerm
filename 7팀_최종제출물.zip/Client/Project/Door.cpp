#include "stdafx.h"
#include "Door.h"
#include "Obstacle.h"

Door::Door() {

}

Door::~Door() {

}